height = int(input("Insert height: "))
width = int(input("Insert width: "))

circumference = 2 * height + 2 * width
area = height * width

print("The circumference is: " + str(circumference))
print("The area is: " + str(area))
