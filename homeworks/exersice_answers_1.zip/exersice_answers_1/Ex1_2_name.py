LINE = "#################"

name = input("Please insert your full name: ")

print(LINE)
print('# ' + name + ' #')
print(LINE)
