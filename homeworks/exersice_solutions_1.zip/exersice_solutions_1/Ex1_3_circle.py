PI = 3.14

radius = int(input("Please insert a circle radius: "))

circumference = 2 * PI * radius
area = PI * radius * radius

print("The circumference is: " + str(circumference))
print("The area is: " + str(area))
