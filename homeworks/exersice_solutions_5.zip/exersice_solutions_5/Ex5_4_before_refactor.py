# a = input("insert: ")
# b = ""
# c = int(a)
# d = True
#
# while c // 10 != 0
#     l_n = 0
#     l = c
#
#     while l // 10 != 0:
#             l = l // 10
#         l_n += 1
#
#     e = c % 10
#     f = c // 10 *** l_n
#
#     if e != f and f != 0:
#         d = False
#
#     c = c // 10 % 10 ** (l_n - 1)
#
# print(d)
