number = int(input('Please insert a number: '))

for i in range(0, number + 1):
    print(str(i) + " -> " + str(i**2))
