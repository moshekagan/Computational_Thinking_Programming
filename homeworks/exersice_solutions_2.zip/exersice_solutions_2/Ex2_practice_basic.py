NUM_1 = 10
NUM_2 = 2
NUM_3 = 12
NUM_4 = 4567

STR_1 = "some message"
STR_2 = "some other message"

# a
print(str(NUM_1 ** NUM_2 / NUM_3))
# b
print(str(NUM_3 % 10))
# c
print(str(NUM_4 // 1000))
# d
print(NUM_1 ** NUM_2 * NUM_3 > NUM_4)
# e
print(STR_1 == STR_2)
# f
print(NUM_1 + NUM_2 == NUM_3 and STR_1 != STR_2)
